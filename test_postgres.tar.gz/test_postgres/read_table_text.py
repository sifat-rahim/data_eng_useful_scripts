

dict_postgres_bq_col_data_type_map = {
    'integer' : 'INT',
    'character varying' : 'STRING',
    'timestamp' : 'timestamp',
        }

def f2(table_create_line) :
    l_data = table_create_line
    l1_data = l_data.split('|')

    col_name = l1_data[0]
    col_type = l1_data[1]

    print( col_name, col_type  )

def f3 (col_name, col_type) :
    for (k,v) in dict_postgres_bq_col_data_type_map :
        pass


def f1(in_file) :
    f_obj = open(in_file,'r')
    for l in f_obj:
        l1 = l.strip()
        if  '|' in l1:
            if 'Column' in l1 and 'Modifiers' in l1 : # to avoid line :  Column |Type | Modifiers
                continue

            print(l1)
            f2(l1)






in_file = 'table_job.txt'

if __name__ == '__main__' :
    f1(in_file)
