
import os
import sys
import json
import psycopg2 as pg  # sudo pip3 install psycopg2

'''
 import yaml
 file_name = '/home/vm-user/python_projects/jomao-scripts/v3/configs/secrete.yaml'
 try :
   with open(file_name, 'r') as f_obj :
   d_config=yaml.safe_load(f_obj) as f_obj :
   print(d_config)
 except yaml.YAMLError as exc:
   print(exc)

print(d_config)
for i in parsed_yaml['dbs'] :
    print (i)
    print ( i['id'] )
'''

def get_db_conn(config_file, db_tag) :
	'''
	This f() triest to connect a database, that has a match with config.txt file and return the conn
	'''

	try :
	    fp          = open(config_file,'r')
	    config_dict = json.load(fp)   #
	    host        = config_dict[db_tag]['host']
	    db_name     = config_dict[db_tag]['db_name']
	    user        = config_dict[db_tag]['user']
	    password    = config_dict[db_tag]['password']
	    db_port     = config_dict[db_tag]['port']

	    # print (host, db_name,user,password,db_port)

	    conn_string = "host='{host}' dbname='{db_name}' user='{user}' password='{password}' port={db_port} ".format(host=host,db_name=db_name,user=user,password=password,db_port=db_port)
	    conn = pg.connect(conn_string)

	except Exception as e:
	    print (str(e))
	    print ("!!ERROR!!, config file load ERROR!!.. exiting program..")
	    sys.exit(0)

	return conn


if __name__ == '__main__':
        config_file = os.path.join( os.getcwd(), 'config.txt')
        db_conn = get_db_conn(config_file,'karagar_db')
        print(db_conn)

        # check query execution after getting db_conn
        from pgspecial.main import PGSpecial
        pgs = PGSpecial()
        cur = db_conn.cursor()
        for title, rows, headers, status in pgs.execute(cur, '\\d jobs'):
            print ('title = ', title)
            print( 'headers = ', headers)
            #for r in rows :
            #    print( r )
            print ('rows = ',rows)
            print ('status = ',status)
