
import os
import sys
import yaml
import json
import psycopg2 as pg  # sudo pip3 install psycopg2


def get_db_conn(config_file, db_tag) :
        '''
        This f() triest to connect a database, that has a match with config.json file and return the conn
        '''

        try :
            f_obj = open(config_file,'r')
            db_dict = {}

            if config_file.endswith('.yaml')  :
                config_dict = yaml.safe_load(f_obj)
                for i in config_dict['dbs'] :  # config_dict['dbs'] is the list of all config
                    if i['id'] == db_tag :
                        db_dict = i
                        print(i)

            elif config_file.endswith('.json') :
                config_dict = json.load(f_obj)
                pass

            host        = db_dict['host']
            db_name     = db_dict['db']
            user        = db_dict['user']
            password    = db_dict['password']
            db_port     = db_dict['port']

            # print (host, db_name,user,password,db_port)

            conn_string = "host='{host}' dbname='{db_name}' user='{user}' password='{password}' port={db_port} ".format(host=host,db_name=db_name,user=user,password=password,db_port=db_port)
            conn = pg.connect(conn_string)

        except Exception as e:
            print (str(e))
            print ("!!ERROR!!, config file load ERROR!!.. exiting program..")
            sys.exit(0)

        return conn


if __name__ == '__main__':
        #config_file = os.path.join( os.getcwd(), '../config.txt')
        config_file = '/home/vm-user/python_projects/jomao-scripts/v3/configs/secrete.yaml'

        db_conn = get_db_conn(config_file,'hermes') # postgres_test
        print(db_conn)

        # check query execution after getting db_conn
        import pandas as pd
        #sql_str = "select count(*) from abc"  # table name : t2
        #sql_str = 'select count(*) from abc'
        #df = pd.read_sql(sql_str,con=db_conn)
        #print(df)
